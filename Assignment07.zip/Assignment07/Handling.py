# ....................#
# Title: Assignment 07 Handling Exceptions
# Dev: Fosman
# Date: Feb 23, 2019
# Desc: Handling Exceptions for student age
# Change Log(Created Handling Exceptions, Fatima, 2/23/19)
# ...................#
    
try: 
    integer = int(input('Enter age of student: ')) #asks to enter name
    
except (ValueError, TabError, ZeroDivisionError): #calls out the specific exception type to be applied
    print('Please try again and enter a number')
    
else:
    print('You entered', integer, 'as the age of the student') #if no eception code bypasses and prints the age.
    
input('\nPress the Enter key to confirm.') # exist the program


#Python Documents/_PythonClass/Assignment07/Handling.py
