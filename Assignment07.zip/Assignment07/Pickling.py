# ....................#
# Title: Assignment 07 Pickling student names
# Dev: Fosman
# Date: Feb 23, 2019
# Desc: Pickling student name
# Change Log(Created Pickling student names, Fatima, 2/23/19)
# ...................#

import pickle

#data
student_lst = ['Fatima', 'Hanan', 'Suha', 'Ayan', 'Rahima'] 
filename = 'student'

#open file, store data with pickle.dump method, close file
outfile = open(filename, 'wb')
pickle.dump(student_lst, outfile)
outfile.close()

#Unpickle file to read it back and close

infile = open(filename, 'rb')
new_lst = pickle.load (infile)
infile.close()

#print the unpickled file
print(new_lst)

#Compare pickled and unpickled files

print(new_lst == student_lst)
print(type(new_lst))



#Python Documents/_PythonClass/Assignment07/Pickling.py

