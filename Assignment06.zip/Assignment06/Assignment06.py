# ....................#
# Title: Assignment 06
# Dev: Fosman
# Date: Feb 18, 2019
# Desc: Create a to do list, using Functions and Class
# Change Log(Created To Do list, Fatima, 2/18/19)
# ...................#

#----------------Class to show menu options ask for input from user-------------------------------#

class AskUser:
    ''' Set of functions for menu options '''

    @staticmethod
    def AskForOption():  # Shows user options and allow input
        print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strOption = str(input("Chose an option? [1 to 5] - "))
        print()
        return strOption

    def AskForTask():  
        strTask = str(input("What is the task? - "))
        return strTask

    def AskforPriority():  
        strPriority = str(input("What is the priority?"))
        return strPriority

    def AskToSaveData(): 
        strSaveData = str(input("Save this data to list?"))
        return strSaveData

    
#--------------------Class for file activity-------------------------------#

class fileActivity:
    ''' functions to read and save the file '''

    @staticmethod
    def ReadFile(): #reads what is on the file
        objFile = open(FileName, "r")
        for line in objFile:
            lstData = line.split(",")
            dicRow = {"Task":lstData[0].strip(), "Priority":lstData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    def SaveToFile(): # Saves data to file
            objFile = open(FileName, "w")
            for dicRow in Table:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            
#----------------Class to make changes to the data-------------------------------#

class changeData:
    
    '''Functions to show, save and remove data '''

    @staticmethod
    def PrintTasks(): # Shows list in table
        for row in table:
            print(row["Task"] + "(" + row["Priority"] + ")")

    def DataSaved(): # Inform user data is saved
        input("The list is saved")

    def ItemRemoved(): # Informs user data is removed
        print("The task is removed from the list")
        
#----------------Class to make changes to the table-------------------------------#

class changeTable:
    
    ''' Functions to add and review data'''

    @staticmethod
    def AddItem(Task,Priority): # Adds task to table
        dicRow = {"Task": Task, "Priority": Priority}
        lstTable.append(dicRow)
        return lstTable

    
# ---------------------------------------------------------------------------- #
#-----------------------------------------#

objFile = open ('ToDo.txt', 'r')
strData = ""
dicRow = {}
lstTable = []

#  1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

for row in objFile:
    strData = row.strip("\n")
    lstData = strData.split(",")
    dicRow = {"Task":lstData[0],"Priority":lstData[1]}
    lstTable.append(dicRow)
objFile.close()

# 2- Display a menu of options to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strOption = str(input("Chose an option? [1 to 5] - "))

    # 3 -Show the current items in the table
    if (strOption.strip() == '1'):
        for row in lstTable:
            print(row["Task"], ",", row["Priority"])
        continue
    # 4 - Add a new item to the list/Table
    elif(strOption.strip() == '2'):
        strNewTask = input("What is the task? ")
        strNewPriority = input("What is the priority? ")
        dicNewItem = {"Task":strNewTask,"Priority":strNewPriority}
        lstTable.append(dicNewItem)
        print("\n The task is added to the list.")
        continue
    #  5 - Remove item from the list/Table
    elif(strOption == '3'):
        for item in lstTable:
            print(lstTable.index(item),item)
        intDeleteItem = int(input("Enter a number to delete: "))
        del lstTable[intDeleteItem]
        print("\n The task is removed from the list.")
        continue
    # 6 - Save tasks to the ToDo.txt file
    elif(strOption == '4'):
        objFile = open('ToDo.txt', 'w')
        for row in lstTable:
            strRow = str(row["Task"] +","+ row["Priority"])
            objFile.write(strRow+ "\n")
        objFile.close()
        print("\n The list is saved")
        continue
    #7- Exit the program
    elif (strOption == '5'):
        break 


#Terminal code Python Documents/_PythonClass/Assignment06/Assignment06.py

